# functionmonitor/__init__.py
from .core import FunctionMonitor, get_fm

__version__ = "0.1.2"
__author__ = "Dennis Chou"
